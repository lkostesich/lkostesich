package edu.wccnet.lkostesich.pizzaMP4.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import edu.wccnet.lkostesich.pizzaMP4.CustomerInfo;

public class CreateDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			Pizza pizza = new Pizza("Pepperoni", "Large");
			Pizza_order pizza_order = new Pizza_order();
			CustomerInfo customerInfo = new CustomerInfo("981", "Howell", "MI", "48843");
			pizza_order.setCustomerInfo(customerInfo);
			pizza.setPizza_order(pizza_order);
			pizza_order.addPizza(pizza);
			
			
			Pizza pizza3 = new Pizza("Pineapple", "Large");

			Pizza_order pizza_order2 = new Pizza_order();
			CustomerInfo customerInfo2 = new CustomerInfo("123", "Howell", "MI", "48843");
			pizza_order2.setCustomerInfo(customerInfo2);
			
			Pizza pizza2 = new Pizza("Sausage", "Large");
			pizza2.setPizza_order(pizza_order2);
			pizza_order2.addPizza(pizza2);
			
			
			pizza3.setPizza_order(pizza_order2);
			pizza_order2.addPizza(pizza3);
			
			session.persist(pizza_order2);
			session.persist(pizza_order);
	
			//session.persist(pizza);
			
			System.out.println("Pizza Order: " + pizza_order);
			
			System.out.println("Pizza Order 2: " + pizza_order2);
			
			session.getTransaction().commit();
		}finally {
			session.close();
			factory.close();
		}
		
	}

}
