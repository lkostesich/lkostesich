package edu.wccnet.lkostesich.pizzaMP4.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import edu.wccnet.lkostesich.pizzaMP4.CustomerInfo;

public class DeleteDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
	
		
		
		
		
		
		}finally {
		session.close();
		factory.close();
	}
	
}

}