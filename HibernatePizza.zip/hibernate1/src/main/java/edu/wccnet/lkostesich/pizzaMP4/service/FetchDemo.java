package edu.wccnet.lkostesich.pizzaMP4.service;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import edu.wccnet.lkostesich.pizzaMP4.CustomerInfo;

public class FetchDemo {
	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
		
			
				
			
			Query<CustomerInfo> query = session
					.createQuery("select po.customerInfo from Pizza_order po "
					+ "where po.customerInfo.id = :customerId",  CustomerInfo.class);
			//query.setParameter("customerId", 5);
	//CustomerInfo customerInfo = (CustomerInfo) query.getSingleResult();
			
		//	System.out.println(customerInfo);
			//int i = query.getFirstResult();
			java.util.List<CustomerInfo> query1 =  session.createQuery("select po.customerInfo from Pizza_order po "
					+ "where po.customerInfo.id > 0",  CustomerInfo.class).getResultList();
		
			System.out.println(query1);
			
			
		
			//java.util.List<Pizza> query2 =  session.createQuery("select po.order_id from Pizza_order po "
			//		+ "where po.order_id.id > 0",  Pizza.class).getResultList();
			//System.out.println(query2);
			

			//List query3 = session.createQuery("select po.Pizza_order from Pizza_order po "
			//		+ "where po.pizza_order.id > 0", Pizza_order.class
			//		).getResultList();
	
			
			Scanner scan = new Scanner(System.in);
			System.out.println("Select Customer...");
			int userName = scan.nextInt();
			query.setParameter("customerId", userName);
			CustomerInfo customerInfo1 = (query.getSingleResult());
			System.out.println(userName + " " + customerInfo1);

			
		


	//String hql = "from Pizza_order po ";
	//Query query2 = session.createQuery(hql);
	//List results = (List) query.list();
	//System.out.println(results);

			

			
		
			
			
			
			
			
		
			
			//final <CustomerInfo> list = query.list();


			// session.persist(college);
			//System.out.println(query.getResultList());

			session.getTransaction().commit();
			//System.out.println(customerInfo.getClass());
		} finally {
			session.close();
			factory.close();
		}

	}

}
