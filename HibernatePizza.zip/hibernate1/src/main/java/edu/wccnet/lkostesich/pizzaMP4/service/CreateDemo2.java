package edu.wccnet.lkostesich.pizzaMP4.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import edu.wccnet.lkostesich.pizzaMP4.CustomerInfo;

public class CreateDemo2 {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			CustomerInfo customerInfo = session.get(CustomerInfo.class, 10);
			
			
			
			session.save(customerInfo);
			
			System.out.println(customerInfo);
			Pizza pizza = new Pizza("Cheese", "Small");
			Pizza_order pizza_order = new Pizza_order();
			pizza_order.setCustomerInfo(customerInfo);
			pizza.setPizza_order(pizza_order);
			pizza_order.addPizza(pizza);
			session.persist(pizza_order);
			
			
	
			//session.persist(pizza);
			
			
			session.getTransaction().commit();
			//System.out.println(customerInfo.getCustomerInfo());
		}finally {
			session.close();
			factory.close();
		}
		
	}

}
