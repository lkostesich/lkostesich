package edu.wccnet.lkostesich.IoCDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class IoCDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//iBird chickadee = new SeedsEater();
		//System.out.println(chickadee.getEatingHabit());
		ApplicationContext context = new FileSystemXmlApplicationContext("beanConfig.xml");
		iBird bird = (iBird)context.getBean("bird");
		System.out.println(bird.getEatingHabit());
		((FileSystemXmlApplicationContext)context).close();
	}

}
