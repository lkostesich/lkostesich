package edu.wccnet.lkostesich.IoCDemo;

public interface iBird {
	String getEatingHabit();

}
