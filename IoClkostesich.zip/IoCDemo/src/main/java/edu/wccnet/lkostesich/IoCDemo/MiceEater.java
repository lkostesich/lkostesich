package edu.wccnet.lkostesich.IoCDemo;

public class MiceEater implements iBird {

	public String getEatingHabit() {
		// TODO Auto-generated method stub
		return "I eat mice.";
	}

}
