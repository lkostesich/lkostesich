package edu.wccnet.lkostesich.IoCDemo;

public class Chickadee {
	public String getEatingHabit() {
		return "I eat seeds.";				
	}
}
