package edu.wccnet.lkostesich.IoCDemo;

public class Owl {
	public String getEatHabit() {
		return "I eat mice.";
	}

}
