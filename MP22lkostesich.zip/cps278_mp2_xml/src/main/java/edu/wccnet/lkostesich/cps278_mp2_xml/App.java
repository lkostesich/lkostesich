package edu.wccnet.lkostesich.cps278_mp2_xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	 ApplicationContext context = new ClassPathXmlApplicationContext("beanConfig.xml");
        Battle battle = (Battle)context.getBean("battle");
        battle.fight();
        
        ((ClassPathXmlApplicationContext)context).close();
        		
    }
}
