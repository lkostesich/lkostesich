package edu.wccnet.lkostesich.cps278_mp2_xml;

public class Punch implements FightingPower {

	public String getFightingPowerDesc() {
		// TODO Auto-generated method stub
		return "punching";
	}

}
