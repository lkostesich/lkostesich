package edu.wccnet.lkostesich.cps278_mp2_xml;

public class FightingMs implements FightingPower {

	public String getFightingPowerDesc() {
		// TODO Auto-generated method stub
		return "throwing Rock";
	}

}
