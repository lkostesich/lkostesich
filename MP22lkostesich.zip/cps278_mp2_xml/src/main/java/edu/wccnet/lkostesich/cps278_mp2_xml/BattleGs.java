package edu.wccnet.lkostesich.cps278_mp2_xml;

public class BattleGs implements BattleGround {

	public String getBattleGroundDesc() {
		// TODO Auto-generated method stub
		return " Lava Lake";
	}

}
