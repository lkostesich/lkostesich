package edu.wccnet.lkostesich.demo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(College.class)
				.addAnnotatedClass(Company.class)
				.addAnnotatedClass(Campus.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Company canvas = session.get(Company.class, 3);
			
			
		
			//Campus ypsiCampus = session.get(Campus.class, 3);
			session.delete(canvas);
			//session.remove(college);
			//session.save(college);
			//session.persist(college);
	
			session.getTransaction().commit();
		}finally {
			session.close();
			factory.close();
		}
		
	}

}
