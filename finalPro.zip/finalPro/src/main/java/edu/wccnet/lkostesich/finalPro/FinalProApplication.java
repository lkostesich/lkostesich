package edu.wccnet.lkostesich.finalPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalProApplication.class, args);
	}

}
