package edu.wccnet.lkostesich.pizzaMP4.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "pizza_order")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@OneToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinColumn(name = "customer_id")
	private Customer customer;
	

	@OneToMany (mappedBy = "order", cascade = CascadeType.ALL)
	private List<Pizza> pizzas = new ArrayList<Pizza>();


	public List<Pizza> getPizzas() {
		return pizzas;
	}
	public void add(Pizza newPizza) {
		pizzas.add(newPizza);
		
		newPizza.setPizza_order(this);
	}
	public void remove(Pizza pizza) {
		pizzas.remove(pizza);
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}
	public Order(Customer customer) {
		this.customer = customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Order(){
		
	}
	@Override
	public String toString() {
		return "Pizza_order [id=" + id + ", customerInfo=" + customer + ", pizzas=" + pizzas + "]";
	}


}
