package edu.wccnet.lkostesich.pizzaMP4.service;

import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CreateDemo2 {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			//Customer customerInfo = session.get(Customer.class, 10);
			Query query = session.createQuery("from Order o where o.customer.id= :id");
			Scanner scan = new Scanner(System.in);
			List<Customer> customerList = session.createQuery("from Customer").getResultList();
			System.out.println(customerList);
			System.out.println("which customer Id would you like?");
			int customerId = scan.nextInt();
			query.setParameter("id", customerId);
			Order order = (Order)query.getSingleResult();
			System.out.println(order);
			Pizza pizza3= new Pizza("Pep", "L");
			order.add(pizza3);
			pizza3.setPizza_order(order);
			session.persist(order);
			System.out.println(order);
			
			
			
		//	session.save(customerInfo);
			
			//System.out.println(customerInfo);
			//Pizza pizza = new Pizza("Cheese", "Small");
			//Order pizza_order = new Order(customerInfo);
		//	pizza_order.setCustomer(customerInfo);
		//	pizza.setPizza_order(pizza_order);
			//pizza_order.add(pizza);
			//session.persist(pizza_order);
			
			
	
			//session.persist(pizza);
			
			
			session.getTransaction().commit();
			//System.out.println(customerInfo.getCustomerInfo());
		}finally {
			session.close();
			factory.close();
		}
		
	}

}
