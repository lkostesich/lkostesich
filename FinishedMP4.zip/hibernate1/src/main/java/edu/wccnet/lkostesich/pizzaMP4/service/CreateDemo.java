package edu.wccnet.lkostesich.pizzaMP4.service;



import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CreateDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Customer cust1 = new Customer("433", "Highland", "MI", "33333");
			Pizza pizza0= new Pizza("Pep", "L");
			Pizza pizza9= new Pizza("Sas", "M");
			
			Order order0 = new Order(cust1);
			pizza0.setPizza_order(order0);
			pizza9.setPizza_order(order0);
			order0.add(pizza0);
			order0.add(pizza9);
			
			session.persist(order0);
			System.out.println(order0);
			
			Customer cust2 = new Customer("981", "Howell", "MI", "48843");
			Pizza pizza1= new Pizza("Mush", "L");
			Order order1 =  new Order(cust2);
			pizza1.setPizza_order(order1);
			order1.add(pizza1);
			session.persist(order1);
			System.out.println(order1);
			
			List<Customer> customerList = session.createQuery("from Customer").getResultList();
			System.out.println(customerList);
			
			Query query = session.createQuery("from Order o where o.customer.id= :id");
			query.setParameter("id", 22);
			Order order = (Order)query.getSingleResult();
			System.out.println(order);
			
			
			
			//Pizza pizza = new Pizza("Pepperoni", "Large");
			//Order pizza_order = new Order();
			//Customer customerInfo = new Customer("981", "Howell", "MI", "48843");
			//pizza_order.setCustomer(customerInfo);
			//pizza.setPizza_order(pizza_order);
			//pizza_order.add(pizza);
		//	Order order1 = new Order(customerInfo);
			
			
			//Pizza pizza3 = new Pizza("Pineapple", "Large");

			//Order pizza_order2 = new Order();
			//Customer customerInfo2 = new Customer("123", "Brighton", "MI", "48843");
			//pizza_order2.setCustomer(customerInfo2);
			
			//Pizza pizza2 = new Pizza("Sausage", "Large");
			//pizza2.setPizza_order(pizza_order2);
			//pizza_order2.add(pizza2);
			
			
			//pizza3.setPizza_order(pizza_order2);
		//	pizza_order2.add(pizza3);
			
			//session.persist(pizza_order2);
		//	session.persist(pizza_order);
	
			//session.persist(pizza);
			
		//	System.out.println("Pizza Order: " + pizza_order);
			
		//	System.out.println("Pizza Order 2: " + pizza_order2);
			
			session.getTransaction().commit();
		}finally {
			session.close();
			factory.close();
		}
		
	}

}
