package edu.wccnet.lkostesich.pizzaMP4.service;

import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Order.class)
				.buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			Query query = session.createQuery("from Order o where o.customer.id= :id");
			Scanner scan = new Scanner(System.in);
			List<Customer> orderList = session.createQuery("from Order").getResultList();
			System.out.println(orderList);
			System.out.println("which Order Id would you like?");
			int orderId = scan.nextInt();
			query.setParameter("id", orderId);
			Order order = session.get(Order.class, orderId);
			session.remove(order);
			session.getTransaction().commit();
	
		
		
		
		
		
		}finally {
		session.close();
		factory.close();
	}
	
}

}