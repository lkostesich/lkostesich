package edu.wccnet.lkostesich.pizzaMP4.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "street")
	private String street;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "zip")
	private String zip;
						//
	//@OneToMany(mappedBy="customer", cascade = CascadeType.ALL)
	//private List<Order> orders = new ArrayList<Order>();
	//public void add(Order newOrder) {
	//	orders.add(newOrder);
	//	newOrder.setCustomer(this);
	//}
	//public void remove(Order order) {
	//	orders.remove(order);
//	}

	public Customer() {

	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public Customer(String street, String city, String state, String zip) {
		super();
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}
	@Override
	public String toString() {
		return "CustomerInfo [id=" + id + ", street=" + street + ", city=" + city + ", state=" + state + ", zip=" + zip
				+  "]";
	}




}
