package edu.wccnet.lozhang.student.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import edu.wccnet.lozhang.student.entity.Customer;
import edu.wccnet.lozhang.student.entity.Pizza;



@Entity
@Table(name = "pizza_order")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@ManyToOne (cascade = CascadeType.DETACH)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	

	@OneToMany (mappedBy = "pizza_order", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Pizza> pizzas = new ArrayList<Pizza>();
	public Order() {
	}


	public List<Pizza> getPizzas() {
		return pizzas;
	}
	public void addPizza(Pizza pizza) {
		pizzas.add(pizza);
		pizza.setPizza_order(this);
	}
	public void remove(Pizza pizza) {
		pizzas.remove(pizza);
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}
	
	public Order(Customer customerInfo) {
		this.customer = customerInfo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}
	

	public void setCustomer(Customer customerInfo) {
		this.customer = customerInfo;
	}
	@Override
	public String toString() {
		return "Pizza_order [id=" + id + ", customer=" + customer + ", pizzas=" + pizzas + "]";
	}

}
