package edu.wccnet.lozhang.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import edu.wccnet.lozhang.student.entity.Customer;
import edu.wccnet.lozhang.student.entity.Order;
import edu.wccnet.lozhang.student.entity.Pizza;
import edu.wccnet.lozhang.student.service.CustomerService;
import edu.wccnet.lozhang.student.service.PizzaService;

@Controller
@RequestMapping("/customers")
public class MainController {

	
	@Autowired
	private CustomerService customerService;
	@Autowired
	private PizzaService pizzaService;
	
	@GetMapping("/list")
	public String list(Model model) {
		model.addAttribute("customers", customerService.getCustomers());
		return "list-customers";
	}

	@GetMapping("/add")
	public String add(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "add-customer";
	}

	@PostMapping("/save")
	public String save(@ModelAttribute("customer") Customer customer ) {		
		customerService.save(customer);
		return "redirect: list";
	}
	
	@GetMapping("/addPizza")
	public String addPizza(Model model, @RequestParam("id") int orderId) {
		Order order = customerService.getOrder(orderId);
		Pizza pizza = new Pizza();
		pizza.setPizza_order(order);
		model.addAttribute("myPizza", pizza);
		model.addAttribute("orderId", orderId);
		return "add-pizza";
	}
	
	@GetMapping("/addOrder")
	public String addOrder(Model model, @RequestParam("id") int customerID) {
		Order order = customerService.createOrder(customerID);
		Pizza pizza = new Pizza();
		pizza.setPizza_order(order);
		model.addAttribute("myPizza", pizza);
		model.addAttribute("orderId", order.getId());
		return "add-pizza";
	}
	
	@GetMapping("/deleteOrder")
	public String deleteOrder(Model model, RedirectAttributes redirectAttributes, @RequestParam("id") int id) {	
		Order order = customerService.getOrder(id);
		customerService.deleteOrder(id);
		redirectAttributes.addAttribute("id", order.getCustomer().getId());
		return "redirect:orderHistory";
	}
	
	@PostMapping("/savePizza")
	public String save(@ModelAttribute("pizza") Pizza pizza, Model model) {		
		pizza = customerService.savePizza(pizza);		
		List<Pizza> pizzas = customerService.getPizzas(pizza.getPizza_order().getId());
		model.addAttribute("pizzas", pizzas);
		model.addAttribute("orderId", pizza.getPizza_order().getId());
		model.addAttribute("customerId", pizzas.get(0).getPizza_order().getCustomer().getId());
		return "order-cart";
	}
	
	@GetMapping("/update")
	public String upate(Model model, @RequestParam("id") int id) {		
		Customer customer = customerService.get(id);
		model.addAttribute("customer", customer);
		return "add-customer";
	}
	
	@GetMapping("/orderHistory")
	public String orderHistory(Model model, @RequestParam("id") int customerID) {
		model.addAttribute("orders", customerService.getOrderHistory(customerID));
		model.addAttribute("customerId", customerID);
		return "order-history";
	}
	
	@GetMapping("/orderCart")
	public String orderCart(Model model, @RequestParam("id") int orderId) {
		List<Pizza> pizzas = customerService.getPizzas(orderId);
		model.addAttribute("pizzas", pizzas);
		model.addAttribute("orderId", orderId);
		model.addAttribute("customerId", pizzas.get(0).getPizza_order().getCustomer().getId());
		return "order-cart";
	}
	
	@GetMapping("/deletePizza")
	public String deletePizza(Model model,  RedirectAttributes redirectAttributes, @RequestParam("id") int pizzaId) {	
		Pizza pizza = customerService.getPizza(pizzaId);
		customerService.deletePizza(pizzaId);
		redirectAttributes.addAttribute("id", pizza.getPizza_order().getId());
		return "redirect:orderCart";
	}

	
	@GetMapping("/delete")
	public String delete(Model model, @RequestParam("id") int id) {		
		customerService.deleteCustomer(id);
		return "redirect:list";
	}
	
	@ModelAttribute
	public void populateForm(Model model)
	{
		model.addAttribute("sizeList", pizzaService.populateSize());
		model.addAttribute("stateList", pizzaService.populateState());
		model.addAttribute("toppingsList", pizzaService.populateToppings());
	}

	
}