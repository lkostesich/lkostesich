package edu.wccnet.lozhang.student.service;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class PizzaService {
	
	public Map<String, String> populateSize() {
		Map<String, String> sizeList = new LinkedHashMap<String,String>();
		sizeList.put("Small", "Small");
		sizeList.put("Medium", "Medium");
		sizeList.put("Large", "Large");
		
		return sizeList;
	}
	public Map<String, String> populateToppings() {
		Map<String, String> topList = new LinkedHashMap<String,String>();
		topList.put("Mushroom", "Mushroom");
		topList.put("Pineapple", "Pineapple");
		topList.put("Pepporoni", "Pepporoni");
		topList.put("Sausage", "Sausage");
		
		return topList;

	}
	public Map<String, String> populateState() {
		Map<String, String> stateList = new LinkedHashMap<String,String>();
		stateList.put("Michigan", "Michigan");
		stateList.put("Ohio", "Ohio");
		stateList.put("Illinois", "Illinois");
		
		return stateList;
	}


	
}
