package edu.wccnet.lozhang.student.service;

import java.util.List;


import edu.wccnet.lozhang.student.entity.Customer;
import edu.wccnet.lozhang.student.entity.Order;
import edu.wccnet.lozhang.student.entity.Pizza;

public interface CustomerService {
	public List<Customer> getCustomers();
	
	public void save(Customer customer);

	public Customer get(int id);

	public void deleteCustomer(int id);
	
	public List<Order> getOrderHistory(int customerId);
	
	public Order createOrder(int customerId);
	
	public void deleteOrder(int orderId);
	
	public void deletePizza(int pizzaId);
	
	public Pizza savePizza(Pizza pizza);

	public List<Pizza> getPizzas(int id);

	public Order getOrder(int orderId);

	public Pizza getPizza(int pizzaId);

	public List<Order> getOrders();

	public Order saveOrder(Order order);

}