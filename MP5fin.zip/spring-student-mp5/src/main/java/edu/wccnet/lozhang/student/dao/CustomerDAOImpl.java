package edu.wccnet.lozhang.student.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.wccnet.lozhang.student.entity.Customer;
import edu.wccnet.lozhang.student.entity.Order;
import edu.wccnet.lozhang.student.entity.Pizza;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	private CustomerDAO customerDAO;

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Customer> getCustomers() {

		Session session = sessionFactory.getCurrentSession();
		Query<Customer> query = session.createQuery("from Customer c order by c.lastName", Customer.class);
		return query.getResultList();
	}

	@Override
	public void save(Customer customer) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
//		session.save(student);
		session.saveOrUpdate(customer);
	}

	@Override
	public Customer get(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return session.get(Customer.class, id);
	}

	@Override
	public void deleteCustomer(int id) {
		Session session = sessionFactory.getCurrentSession();		
		Customer customer = session.get(Customer.class, id);
		session.remove(customer);	
	}

	@Override
	public List<Order> getOrderHistory(int customerId) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Order o where o.customer.id= :id");
		query.setParameter("id", customerId);
		
		return query.getResultList();
	}

	@Override
	public Order createOrder(int customerId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Customer customer = session.get(Customer.class, customerId);
		Order order = new Order(customer);
		session.save(order);
		return order;
	}

	@Override
	public void deleteOrder(int orderId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Order order = session.get(Order.class, orderId);
		session.delete(order);
		
		
	}

	@Override
	public void deletePizza(int pizzaId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Pizza pizza = session.get(Pizza.class, pizzaId);
		session.delete(pizza);
		
	}

	@Override
	public Pizza savePizza(Pizza pizza) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		int orderId = pizza.getPizza_order().getId();
		Order order = session.get(Order.class, orderId);
		pizza.setPizza_order(order);
		session.save(pizza);
		return pizza;
		
	}

	@Override
	public List<Pizza> getPizzas(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Pizza p where p.pizza_order.id= :id");
		query.setParameter("id", id);
		
		return query.getResultList();
	}

	@Override
	public Order getOrder(int orderId) {
		Session session = sessionFactory.getCurrentSession();
		return session.get(Order.class, orderId);
	}

	@Override
	public Pizza getPizza(int pizzaId) {
		Session session = sessionFactory.getCurrentSession();
		return session.get(Pizza.class, pizzaId);
	}

	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Query<Order> query = session.createQuery("from Order o order by o.customer.lastName", Order.class);
		return query.getResultList();
	}

	@Override
	public Order saveOrder(Order order) {
		Session session = sessionFactory.getCurrentSession();
		Customer customer = session.get(Customer.class, order.getCustomer().getId());
		order.setCustomer(customer);
		order.getPizzas().stream().forEach(pizza -> {			
			pizza.setPizza_order(order);
//			session.save(pizza);		
		});
		session.saveOrUpdate(order);
		return order;
	}

}
