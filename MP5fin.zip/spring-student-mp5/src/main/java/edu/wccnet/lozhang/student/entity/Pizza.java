package edu.wccnet.lozhang.student.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import edu.wccnet.lozhang.student.entity.Order;




@Entity
@Table(name = "pizza")
public class Pizza {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	

	@Column(name = "toppings")
	private String toppings;
	
	@Column(name = "size")
	private String size;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinColumn(name = "order_id")

	private Order pizza_order;

	public Order getPizza_order() {
		return pizza_order;
	}

	public void setPizza_order(Order pizza_order) {
		this.pizza_order = pizza_order;
	}

	public String getToppings() {
		return toppings;
	}

	public void setToppings(String toppings) {
		this.toppings = toppings;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pizza(String toppings, String size) {
		super();
		this.toppings = toppings;
		this.size = size;
	}

	public Pizza() {
	}

	@Override
	public String toString() {
		return "Pizza [id=" + id + ", toppings=" + toppings + ", size=" + size + "]";
	}

}
