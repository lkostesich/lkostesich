package edu.wccnet.lozhang.student.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.wccnet.lozhang.student.entity.Customer;
import edu.wccnet.lozhang.student.service.CustomerService;
import edu.wccnet.lozhang.student.dao.CustomerDAO;

import edu.wccnet.lozhang.student.entity.Order;
import edu.wccnet.lozhang.student.entity.Pizza;


@Service
public class CustomerServiceImpl implements CustomerService {
	
	
	@Autowired
	private CustomerDAO customerDAO;

	@Override
	@Transactional
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return customerDAO.getCustomers();
	}

	@Override
	@Transactional
	public void save(Customer customer) {
		// TODO Auto-generated method stub
		customerDAO.save(customer);
	}

	@Override
	@Transactional
	public Customer get(int id) {
		// TODO Auto-generated method stub
		return customerDAO.get(id);
	}

	@Override
	@Transactional
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		customerDAO.deleteCustomer(id);
	}

	@Override
	@Transactional
	public List<Order> getOrderHistory(int customerId) {
		// TODO Auto-generated method stub
		return customerDAO.getOrderHistory(customerId);
	}

	@Override
	@Transactional
	public Order createOrder(int customerId) {
		// TODO Auto-generated method stub
		return customerDAO.createOrder(customerId);
	}

	@Override
	@Transactional
	public void deleteOrder(int orderId) {
		// TODO Auto-generated method stub
		customerDAO.deleteOrder(orderId);
	}

	@Override
	@Transactional
	public void deletePizza(int pizzaId) {
		// TODO Auto-generated method stub
		customerDAO.deletePizza(pizzaId);
		
	}

	@Override
	@Transactional
	public Pizza savePizza(Pizza pizza) {
		// TODO Auto-generated method stub
		return customerDAO.savePizza(pizza);
	}

	@Override
	@Transactional
	public List<Pizza> getPizzas(int id) {
		// TODO Auto-generated method stub
		return customerDAO.getPizzas(id);
	}

	@Override
	@Transactional
	public Order getOrder(int orderId) {
		// TODO Auto-generated method stub
		return customerDAO.getOrder(orderId);
	}

	@Override
	@Transactional
	public Pizza getPizza(int pizzaId) {
		// TODO Auto-generated method stub
		return customerDAO.getPizza(pizzaId);
	}

	@Override
	@Transactional
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return customerDAO.getOrders();
	}

	@Override
	@Transactional
	public Order saveOrder(Order order) {
		// TODO Auto-generated method stub
		return customerDAO.saveOrder(order);
	}

}
