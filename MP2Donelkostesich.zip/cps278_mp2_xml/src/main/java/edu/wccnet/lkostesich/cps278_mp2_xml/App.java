package edu.wccnet.lkostesich.cps278_mp2_xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext context = new FileSystemXmlApplicationContext("file:src/main/resources/beans1.xml");
        Battle battle = (Battle)context.getBean("battle");
        battle.fight();
    	
        
        ((FileSystemXmlApplicationContext)context).close();
        		
    }
}
