package edu.wccnet.lkostesich.cps278_mp2_xml;

public class Character {
	public String name;
	public int health;
	public int strength;
	private FightingPower fightingPower;
	

	public void setFightingPower(FightingPower fightingPower) {
		this.fightingPower = fightingPower;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public FightingPower getFightingPower() {
		return fightingPower;
	}

	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	
	public String useFightingPower() {
		return name + " is " + fightingPower.getFightingPowerDesc();
	}

}
