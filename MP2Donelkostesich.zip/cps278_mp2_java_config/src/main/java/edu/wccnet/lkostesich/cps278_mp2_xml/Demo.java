package edu.wccnet.lkostesich.cps278_mp2_xml;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BattleGround BattleGs = new BowsersCastle();
		System.out.println(BattleGs.getBattleGroundDesc());
		FightingPower FightingMs = new Punch();
		System.out.println(FightingMs.getFightingPowerDesc());
		System.out.println();
	}

}
