package edu.wccnet.lkostesich.cps278_mp2_xml;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component 
public class Battle {
	@Autowired
	private BattleGround battleGround;
	@Autowired
	private Character character1;
	@Autowired
	private Character character2;
	

	public void setBattleGround(BattleGround battleGround) {
		this.battleGround = battleGround;
	}



	public void setCharacter1(Character character1) {
		this.character1 = character1;
	}



	public void setCharacter2(Character character2) {
		this.character2 = character2;
	}



	public void fight() {

		System.out.println("On " + battleGround.getBattleGroundDesc() + ", ");
		System.out.println(character1.name + " and " + character2.name + " are fighting");
		System.out.println(character1.useFightingPower());
		System.out.println(character2.useFightingPower());
	}

}
