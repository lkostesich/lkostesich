package edu.wccnet.lkostesich.cps278_mp2_xml;

import org.springframework.context.annotation.Bean;
public class MP2BJavaConfig {
	@Bean
	public Character character1() {
		Character character = new Character();
		character.setName("Mario");
		character.setFightingPower(rock());
		return character;
	}
	@Bean
	public Character character2() {
		Character character = new Character();
		character.setName("Mr. Game");
		character.setFightingPower(punch());
		return character;
		
	}
	@Bean
	public FightingPower rock() {
		return new FightingMs();
	}
	@Bean
	public FightingPower punch() {
		return new Punch();
	}
	@Bean
	public BattleGround BowsersCastle() {
		return new BowsersCastle();
	}
	@Bean
	public Battle battle() {
		Battle battle = new Battle();
		battle.setBattleGround(BowsersCastle());
		battle.setCharacter1(character1());
		battle.setCharacter2(character2());
		return battle;
	}
}
