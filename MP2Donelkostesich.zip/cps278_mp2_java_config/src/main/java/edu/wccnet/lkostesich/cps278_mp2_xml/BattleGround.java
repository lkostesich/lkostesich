package edu.wccnet.lkostesich.cps278_mp2_xml;

public interface BattleGround {
	String getBattleGroundDesc();
}
