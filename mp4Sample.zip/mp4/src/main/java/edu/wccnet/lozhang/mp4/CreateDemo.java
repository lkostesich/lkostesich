package edu.wccnet.lozhang.mp4;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import edu.wccnet.lozhang.pizza.entity.CustomerInfo;
import edu.wccnet.lozhang.pizza.entity.Pizza;
import edu.wccnet.lozhang.pizza.entity.Pizza_order;

public class CreateDemo {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class).addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();

			Pizza_order pizza_order1 = new Pizza_order();
			CustomerInfo customerInfo = new CustomerInfo("981", "Howell", "MI", "48843");
			pizza_order1.setCustomerInfo(customerInfo);
			customerInfo.addOrder(pizza_order1);

			Pizza pizza1 = new Pizza("Pepperoni", "Large");
			pizza1.setPizza_order(pizza_order1);
			pizza_order1.addPizza(pizza1);

			Pizza_order pizza_order2 = new Pizza_order();
			pizza_order2.setCustomerInfo(customerInfo);
			customerInfo.addOrder(pizza_order2);

			Pizza pizza2 = new Pizza("Sausage", "Large");
			pizza2.setPizza_order(pizza_order2);
			pizza_order2.addPizza(pizza2);

			Pizza pizza3 = new Pizza("Pineapple", "Large");
			pizza3.setPizza_order(pizza_order2);
			pizza_order2.addPizza(pizza3);

			session.persist(pizza_order2);
			session.persist(pizza_order1);

			System.out.println("Pizza Order 1: " + pizza_order1);
			System.out.println("Pizza Order 2: " + pizza_order2);

			session.getTransaction().commit();
		} finally {
			session.close();
			factory.close();
		}

	}

}
