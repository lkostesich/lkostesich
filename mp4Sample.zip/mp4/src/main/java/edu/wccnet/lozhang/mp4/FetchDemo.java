package edu.wccnet.lozhang.mp4;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import edu.wccnet.lozhang.pizza.entity.CustomerInfo;
import edu.wccnet.lozhang.pizza.entity.Pizza;
import edu.wccnet.lozhang.pizza.entity.Pizza_order;

public class FetchDemo {

	public static void main(String[] args) {

		Scanner scanner = null;
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(CustomerInfo.class).addAnnotatedClass(Pizza.class)
				.addAnnotatedClass(Pizza_order.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();

			List<CustomerInfo> custInfos = session.createQuery("from CustomerInfo").getResultList();
			System.out.println(custInfos);

			scanner = new Scanner(System.in);
			System.out.println("Please select a customer Id");
			int customerId = scanner.nextInt();

			Query query = session.createQuery("from Pizza_order po where po.customerInfo.id = :customerId");
			query.setParameter("customerId", customerId);

			List<Pizza_order> orders = query.getResultList();

			System.out.println(orders);
			session.getTransaction().commit();
		} finally {
			session.close();
			factory.close();
			scanner.close();
		}

	}

}
