package edu.wccnet.lozhang.pizza.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customerinfo")
public class CustomerInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "street")
	private String street;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "zip")
	private String zip;
	
	 @OneToMany(mappedBy="customerInfo")
	 private List<Pizza_order> orders = new ArrayList<Pizza_order>();

	public CustomerInfo() {

	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public CustomerInfo(String street, String city, String state, String zip) {
		super();
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}
	
	public void addOrder(Pizza_order order)
	{
		orders.add(order);
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Pizza_order> getOrders() {
		return orders;
	}

	public void setOrders(List<Pizza_order> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		String info = "CustomerInfo [id=" + id + ", street=" + street + ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", orders= [";
		
		for (Pizza_order order: orders)
		{
			info += " Order ID: " + order.getId();
		}
		info += " ]";
		
		return info;
	}
	

}
