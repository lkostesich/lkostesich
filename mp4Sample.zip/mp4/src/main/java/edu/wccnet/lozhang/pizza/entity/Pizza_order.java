package edu.wccnet.lozhang.pizza.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Pizza_order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private CustomerInfo customerInfo;
	

	@OneToMany (mappedBy = "pizza_order", cascade = CascadeType.ALL)
	private List<Pizza> pizzas = new ArrayList<Pizza>();


	public List<Pizza> getPizzas() {
		return pizzas;
	}
	public void addPizza(Pizza pizza) {
		pizzas.add(pizza);
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}
	

	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}
	@Override
	public String toString() {
		return "Pizza_order [id=" + id + ", customerInfo=" + customerInfo + ", pizzas=" + pizzas + "]";
	}

}
