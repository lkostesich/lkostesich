package edu.wccnet.lkostesich.IoCDemo;

public class SeedsEater implements iBird {

	public String getEatingHabit() {
		// TODO Auto-generated method stub
		return "I eat seeds.";
	}

}
