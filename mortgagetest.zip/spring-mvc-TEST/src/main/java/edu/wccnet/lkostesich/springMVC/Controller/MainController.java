package edu.wccnet.lkostesich.springMVC.Controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.wccnet.lkostesich.springMVC.Domain.Customer;
import edu.wccnet.lkostesich.springMVC.Domain.MortgagePayment;
import edu.wccnet.lkostesich.springMVC.Service.MortgageService;

@Controller
public class MainController {
	@Autowired
	MortgageService mortgageService;
	
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}

	@RequestMapping("/showForm")
	public ModelAndView showForm() {
		return new ModelAndView("info-form", "customer", new Customer());
	}

	@RequestMapping("/processForm")
	public String processForm(
			@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "info-form";
		
		}
		else {
			List<MortgagePayment> payments = mortgageService.getPayments(customer);			
			model.addAttribute("payments", payments);
			model.addAttribute("monthlyPayment", df2.format(mortgageService.monthlyPayment(customer)));
			return "confirmation";
			
	}
	}
	@InitBinder
	public void initialBinderForTrimmingSpaces(WebDataBinder webDataBinder) {
	    StringTrimmerEditor stringTrimEditor = new StringTrimmerEditor(true);
	    webDataBinder.registerCustomEditor(String.class, stringTrimEditor);
	}
}
