package edu.wccnet.lkostesich.springMVC.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import edu.wccnet.lkostesich.springMVC.Domain.Customer;
import edu.wccnet.lkostesich.springMVC.Domain.MortgagePayment;

@Component
public class MortgageService {
	public List <MortgagePayment> getPayments(Customer customer){
		List<MortgagePayment> payments = new ArrayList<MortgagePayment>();
		double monthlyPayment = monthlyPayment(customer);
		double outStandingBalance = customer.getPrincipal() - customer.getDownP();
		for (int i =1; i <= customer.getLoanTerm(); i++) {
			double interestP = outStandingBalance * customer.getInterest() / 12;
			double principalP = monthlyPayment - interestP;
			outStandingBalance -= principalP;
			if (outStandingBalance <=0) {
				interestP += outStandingBalance;
				outStandingBalance =0;
			}
			MortgagePayment payment = new MortgagePayment(i,principalP,interestP, outStandingBalance);
			payments.add(payment);
		}
		return payments;
		
		
	}

	public double monthlyPayment(Customer customer) {
		return (customer.getPrincipal() - customer.getDownP()) * (customer.getInterest() /12)
				* Math.pow(1 + (customer.getInterest() /12), customer.getLoanTerm())
				/ (Math.pow(1 + (customer.getInterest() / 12), customer.getLoanTerm()) - 1);

	}

}
