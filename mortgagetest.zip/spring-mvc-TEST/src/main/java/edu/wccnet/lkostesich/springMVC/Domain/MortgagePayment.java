package edu.wccnet.lkostesich.springMVC.Domain;

import javax.validation.constraints.NotNull;

public class MortgagePayment {

	private int payNum;

	private double principalP;

	private double interestP;

	private double outStandingBalance;
	
	public MortgagePayment(int payNum, double principalP, double interestP, double outStandingBalance) {
		super();
		this.payNum = payNum;
		this.principalP = principalP;
		this.interestP = interestP;
		this.outStandingBalance = outStandingBalance;
	}
	
	public double getPrincipalP() {
		return principalP;
	}
	public void setPrincipalP(double principalP) {
		this.principalP = principalP;
	}
	public int getpayNum() {
		return payNum;
	}
	public void setpayNum(int payNum) {
		this.payNum = payNum;
	}
	public double getInterestP() {
		return interestP;
	}
	public void setInterestP(double interestP) {
		this.interestP = interestP;
	}
	public double getoutStandingBalance() {
		return outStandingBalance;
	}
	public void setoutStandingBalance(double outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}

}
