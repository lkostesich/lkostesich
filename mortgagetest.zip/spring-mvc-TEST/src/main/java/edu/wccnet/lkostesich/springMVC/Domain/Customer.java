package edu.wccnet.lkostesich.springMVC.Domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Customer {
	
	
	@NotNull
	private double principal;
	@NotNull
	private double downP;
	//@Pattern(regexp = "^[0-9]{1}.[0-9]{2}", message = "should be 0.##")
	private double interest;
	@Min(12)
	private int loanTerm;

	public double getPrincipal() {
		return principal;
	}
	public void setPrincipal(double principal) {
		this.principal = principal;
	}
	public double getDownP() {
		return downP;
	}
	public void setDownP(double downP) {
		this.downP = downP;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public int getLoanTerm() {
		return loanTerm;
	}
	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}


}
